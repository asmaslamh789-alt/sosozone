---
name: "sosozon Commerce Design System"
description: "High-density desktop e-commerce design system for sosozon, featuring deep navy navigation chrome, cool gray canvas, crisp white merchandising cards, and golden-yellow/warm-orange conversion actions."
---

## Overview

The **sosozon** design system is engineered for high-density desktop e-commerce discovery and rapid conversion. It balances massive catalog breadth with immediate scannability by pairing authoritative dark-navy navigation chrome (`#131921` and `#232F3E`) against a cool light-gray canvas (`#EAEDED`) and crisp pure-white merchandising modules (`#FFFFFF`).

- **Brand Personality:** Reliable, fast, utilitarian, and value-driven.
- **Target Audience:** Desktop online shoppers comparing specifications, prices, ratings, and delivery speed across multiple categories.
- **Design Style:** Corporate / Modern high-density retail grid with sharp 2px–4px card radii, hairline structural borders, and high-contrast conversion accents.

## Colors

The palette preserves sosozon's signature retail hierarchy: deep midnight navy headers, cool gray page canvas, pure white product cards, golden yellow primary Add-to-Cart buttons, warm orange Buy Now accents, crimson deal badges, and teal-blue interactive links.

```yaml
colors:
  brand-orange: "#FF9900"
  brand-swoosh: "#F3A847"
  nav-primary: "#131921"
  on-nav-primary: "#FFFFFF"
  nav-secondary: "#232F3E"
  on-nav-secondary: "#FFFFFF"
  nav-tertiary: "#37475A"
  on-nav-tertiary: "#FFFFFF"
  surface-canvas: "#EAEDED"
  on-surface-canvas: "#0F1111"
  surface-card: "#FFFFFF"
  on-surface-card: "#0F1111"
  surface-subtle: "#F3F3F3"
  surface-hover: "#F7FAFA"
  ink-primary: "#0F1111"
  ink-muted: "#565959"
  cta-primary: "#FFD814"
  on-cta-primary: "#0F1111"
  cta-primary-hover: "#F7CA00"
  cta-primary-border: "#FCD200"
  cta-secondary: "#FFA41C"
  on-cta-secondary: "#0F1111"
  cta-secondary-hover: "#FA8900"
  search-select: "#E6E6E6"
  search-submit: "#FEBD69"
  on-search-submit: "#0F1111"
  deal-badge: "#CC0C39"
  on-deal-badge: "#FFFFFF"
  price-accent: "#B12704"
  link: "#007185"
  link-hover: "#C7511F"
  star-amber: "#FFA41C"
  border-subtle: "#D5D9D9"
  border-strong: "#BBBFBF"
  success: "#067D62"
```

## Typography

Typography pairs **Mulish** for bold geometric wordmarks, hero headlines, and card titles with **Instrument Sans** for dense product titles, pricing, ratings, and navigation links, plus **Source Code Pro** for SKUs and order codes.

```yaml
typography:
  display-lg:
    fontFamily: "Mulish"
    fontSize: 36px
    fontWeight: 800
    lineHeight: 42px
    letterSpacing: -0.5px
  display-lg-mobile:
    fontFamily: "Mulish"
    fontSize: 28px
    fontWeight: 800
    lineHeight: 34px
    letterSpacing: -0.25px
  headline-lg:
    fontFamily: "Mulish"
    fontSize: 24px
    fontWeight: 700
    lineHeight: 30px
    letterSpacing: -0.2px
  headline-md:
    fontFamily: "Mulish"
    fontSize: 21px
    fontWeight: 700
    lineHeight: 27px
    letterSpacing: 0px
  headline-sm:
    fontFamily: "Mulish"
    fontSize: 18px
    fontWeight: 700
    lineHeight: 24px
    letterSpacing: 0px
  title-md:
    fontFamily: "Instrument Sans"
    fontSize: 16px
    fontWeight: 600
    lineHeight: 22px
    letterSpacing: 0px
  body-md:
    fontFamily: "Instrument Sans"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 20px
    letterSpacing: 0px
  body-sm:
    fontFamily: "Instrument Sans"
    fontSize: 13px
    fontWeight: 400
    lineHeight: 18px
    letterSpacing: 0px
  label-lg:
    fontFamily: "Instrument Sans"
    fontSize: 14px
    fontWeight: 600
    lineHeight: 18px
    letterSpacing: 0px
  label-md:
    fontFamily: "Instrument Sans"
    fontSize: 12px
    fontWeight: 500
    lineHeight: 16px
    letterSpacing: 0px
  label-sm:
    fontFamily: "Instrument Sans"
    fontSize: 11px
    fontWeight: 600
    lineHeight: 14px
    letterSpacing: 0.1px
  mono-sm:
    fontFamily: "Source Code Pro"
    fontSize: 12px
    fontWeight: 500
    lineHeight: 16px
    letterSpacing: 0px
```

## Layout & Spacing

Designed for wide desktop viewports (`1280px`–`1440px+`, max container `1480px` centered) with a tight 4px/8px retail spacing grid. Cards sit in 4-column desktop grids (`gap: 20px`) overlapping the lower edge of the full-bleed hero carousel, followed by horizontal product carousels and editorial promo rows.

```yaml
spacing:
  gutter-xs: 4px
  gutter-sm: 8px
  gutter-md: 12px
  gutter-lg: 16px
  gutter-xl: 20px
  section: 24px
  page-margin: 20px
```

## Elevation & Depth

sosozon relies on crisp tonal separation (`#FFFFFF` cards on `#EAEDED` canvas) and subtle hairline borders (`#D5D9D9`) rather than heavy drop shadows. Interactive overlays (cart drawer, account dropdown, product quick-view modal) use a clean medium shadow and high z-index over a dimmed backdrop.

## Shapes

Subtle, utilitarian corner radii keep high-density retail grids crisp: `2px`–`4px` on merchandising cards, inputs, and badges, and `9999px` pill radii reserved for primary Add-to-Cart and Buy-Now action buttons.

```yaml
rounded:
  none: 0px
  xs: 2px
  sm: 4px
  DEFAULT: 4px
  md: 8px
  lg: 12px
  full: 9999px
```

## Motion & Micro-interaction

Interactions are immediate and mechanical. Hover states on links, buttons, and carousel arrows respond within `100ms`, while drawers and modals slide or fade in within `200ms`.

```yaml
motion:
  state-change:
    duration: 100ms
    delay: 0ms
    timingFunction: ease-out
  surface-enter:
    duration: 200ms
    delay: 0ms
    timingFunction: cubic-bezier(0.2, 0, 0, 1)
  surface-exit:
    duration: 150ms
    delay: 0ms
    timingFunction: cubic-bezier(0.3, 0, 1, 1)
```

## Voice & Content Strategy

Copy is direct, helpful, and commerce-focused. Use sentence case for product titles and descriptions, title case for department headings and navigation items, and action-oriented CTAs ("Add to Cart", "Buy Now", "Shop now", "See more"). Format prices with currency symbol, whole dollars, and superscript cents (e.g., `$129.99`).

## Components

Component implementations live as individual HTML sticker sheet files in
`components/`. Each file contains the canonical, styled HTML components with
`<!-- COMPONENT: name -->` comment markers. Read each file before use.

- **Badge** → `@components/badge.html`: `badge-numeric`, `badge-dot`
- **Button** → `@components/button.html`: `button-primary`, `button-icon`, `button-with-icon`
- **Card** → `@components/card.html`: `card-elevated`, `card-action`, `card-interactive`, `card-interactive-2`
- **Searchbar** → `@components/searchbar.html`: `searchbar-standard`, `searchbar-with-suggestions`
- **Typography** → `@components/typography.html`: `typography-display`, `typography-body`, `typography-label`
